# react-token-auth

Part 1:
    This section will implement the server side logic neede to handle token authentication in React