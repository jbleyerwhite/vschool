import React from 'react';

const Profile = () => {
    return (
        <div>
            <h3>Posts: {}</h3>
        </div>
    );
};

export default Profile;